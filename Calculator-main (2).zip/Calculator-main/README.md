# Calculator
Calculator project done as part of The Odin Project
## Description
This is the Calculator project from The Odin Project.

Link to the live version of my Calculator:
https://abhay2412.github.io/Calculator/


### Future Things want to implement:
-Have a display of pervious calculations 
-Use keyboard input 

### Things Learned:
Using Javascript objects
